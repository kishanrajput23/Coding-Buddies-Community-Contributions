import React from "react";

function Banner() {
  return (
    <div class="banner">
      <img class="banner_img" src="assets/banner.jpg" alt="" />
    </div>
  );
}

export default Banner;
